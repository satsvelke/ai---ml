using System;

namespace LeetCode.StringMatchingInAnArray;

public static class StringMatching
{
    // public static IList<string> GetStringMatching(IList<string> words)
    // {

    //     var finalOutpunt = new List<string>();

    //     for (int i = 0; i < words.Count; i++) // mass
    //     {
    //         var currentWord = words[i]; // mass

    //         for (int j = 0; j < currentWord.Length; j++)
    //         {
    //             for (int p = 0; p < currentWord.Length; p++)
    //             {

    //             }
    //         }

    //     }

    //     return null;
    // }
}
